# Patient Tracker App
This app will help the doctor to maintain patients record.

Features:
1) You can easily add new record of a patient. (ahh Yes! it is possible to store patient's image with textual data 😀)
2) This app will also help you to update the existing record of a patient.
3) You can also delete unnecessary records from the database.
4) You can also view patients record on a single click. This App will give you three options - Search By Patient's ID - Search By Patient's Name - Search by Appointment Date.
5) You can also export patient's record as PDF or PNG.
6) Last but not least, you can also Print patient's record.

Technologies used:
HTML 5, CSS3, bootstrap, Javascript ES6, Google firebase Authentication (Signup and Login), Google firebase Database, Google Firebase Storage (to store patient's Image).

Your feedback will be highly appreciated.

App Link: https://patient-tracker-b3765.firebaseapp.com
                              OR
          https://smshahnawazz.github.io/PatientTrackerApp/
